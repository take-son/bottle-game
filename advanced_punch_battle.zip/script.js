
const player = document.getElementById('player');
const enemy = document.getElementById('enemy');
const playerHpBar = document.getElementById('playerHp');
const enemyHpBar = document.getElementById('enemyHp');
const message = document.getElementById('message');

let playerX = 50;
let playerY = window.innerHeight / 2 - 40;
let enemyX = window.innerWidth - 130;
let enemyY = window.innerHeight / 2 - 40;
let playerHP = 100;
let enemyHP = 100;

// タッチ or マウスドラッグでプレイヤー移動
let isDragging = false;

document.addEventListener('touchstart', e => {
  isDragging = true;
}, false);

document.addEventListener('touchmove', e => {
  if (isDragging) {
    playerX = e.touches[0].clientX - 40;
    playerY = e.touches[0].clientY - 40;
    movePlayer();
  }
}, false);

document.addEventListener('touchend', () => {
  isDragging = false;
}, false);

document.addEventListener('mousedown', () => {
  isDragging = true;
});

document.addEventListener('mousemove', e => {
  if (isDragging) {
    playerX = e.clientX - 40;
    playerY = e.clientY - 40;
    movePlayer();
  }
});

document.addEventListener('mouseup', () => {
  isDragging = false;
});

function movePlayer() {
  player.style.left = playerX + 'px';
  player.style.top = playerY + 'px';
}

// 敵をランダム移動させる
setInterval(() => {
  enemyX += (Math.random() - 0.5) * 100;
  enemyY += (Math.random() - 0.5) * 100;

  // 画面端で跳ね返り
  if (enemyX < 0) enemyX = 0;
  if (enemyX > window.innerWidth - 80) enemyX = window.innerWidth - 80;
  if (enemyY < 0) enemyY = 0;
  if (enemyY > window.innerHeight * 0.8 - 80) enemyY = window.innerHeight * 0.8 - 80;

  enemy.style.left = enemyX + 'px';
  enemy.style.top = enemyY + 'px';
}, 1000);

// タップでパンチ
document.body.addEventListener('click', () => {
  if (getDistance(playerX, playerY, enemyX, enemyY) < 100) {
    punch(player, enemy);
    enemyHP -= 10;
    updateHP();
    checkWin();
  }
});

// 敵の反撃
setInterval(() => {
  if (getDistance(playerX, playerY, enemyX, enemyY) < 100) {
    punch(enemy, player);
    playerHP -= 10;
    updateHP();
    checkWin();
  }
}, 1500);

function punch(attacker, target) {
  attacker.classList.add('punch');
  target.classList.add('hit');
  setTimeout(() => {
    attacker.classList.remove('punch');
    target.classList.remove('hit');
  }, 300);
}

function updateHP() {
  playerHpBar.style.width = playerHP + '%';
  enemyHpBar.style.width = enemyHP + '%';
}

function checkWin() {
  if (enemyHP <= 0) {
    message.innerText = "勝利！！";
    stopGame();
  } else if (playerHP <= 0) {
    message.innerText = "敗北...";
    stopGame();
  }
}

function stopGame() {
  document.body.removeEventListener('click', () => {});
}

// 2点間の距離を求める
function getDistance(x1, y1, x2, y2) {
  return Math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2);
}
